# Hello API

Spring Boot application with a single `/hello` endpoint that returns "Hello World".

## Requirements

- **Bearer token**: `Authorization: Bearer <token>` header is required. If missing or invalid → **401 Unauthorized** with JSON error message.
- **header-test**: Custom header is required. If missing → **400 Bad Request** with JSON error message.

## Run

```bash
mvn spring-boot:run
```

Server runs on port 8080.

## Examples

**Success** (both header and Bearer token present):

```bash
curl -s -X GET http://localhost:8080/hello \
  -H "Authorization: Bearer my-token" \
  -H "header-test: any-value"
```

Response: `{"message":"Hello World"}` (200 OK)

**401** (no or invalid Authorization):

```bash
curl -s -X GET http://localhost:8080/hello -H "header-test: x"
```

Response: `{"error":"Authorization is required. Bearer token is missing or invalid."}` (401)

**400** (missing header-test):

```bash
curl -s -X GET http://localhost:8080/hello -H "Authorization: Bearer my-token"
```

Response: `{"error":"Required header 'header-test' is missing"}` (400)
