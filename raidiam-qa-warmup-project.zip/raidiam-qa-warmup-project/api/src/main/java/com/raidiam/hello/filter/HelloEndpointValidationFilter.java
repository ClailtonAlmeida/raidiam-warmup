package com.raidiam.hello.filter;

import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.MediaType;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Map;

/**
 * Validates /hello requests: requires "header-test" (400 if missing) and
 * "Authorization: Bearer &lt;token&gt;" (401 if missing).
 */
public class HelloEndpointValidationFilter extends OncePerRequestFilter {

    private static final String HEADER_TEST = "header-test";
    private static final String AUTHORIZATION = "Authorization";
    private static final String BEARER_PREFIX = "Bearer ";

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {
        if (!"/hello".equals(request.getRequestURI())) {
            filterChain.doFilter(request, response);
            return;
        }

        // 1. Require header-test -> 400 if missing
        String headerTest = request.getHeader(HEADER_TEST);
        if (headerTest == null || headerTest.isBlank()) {
            sendError(response, HttpServletResponse.SC_BAD_REQUEST,
                    "Required header 'header-test' is missing");
            return;
        }

        // 2. Require Bearer token -> 401 if missing
        String auth = request.getHeader(AUTHORIZATION);
        if (auth == null || !auth.startsWith(BEARER_PREFIX) || auth.substring(BEARER_PREFIX.length()).isBlank()) {
            sendError(response, HttpServletResponse.SC_UNAUTHORIZED,
                    "Authorization is required. Bearer token is missing or invalid.");
            return;
        }

        filterChain.doFilter(request, response);
    }

    private void sendError(HttpServletResponse response, int status, String message) throws IOException {
        response.setStatus(status);
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.getWriter().write(objectMapper.writeValueAsString(Map.of("error", message)));
    }
}
