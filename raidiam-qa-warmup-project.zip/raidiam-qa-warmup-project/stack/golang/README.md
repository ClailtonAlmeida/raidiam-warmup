# Hello API – Test automation (Golang)

Template: **Go testing** + **net/http**.

## Prerequisites

- Go 1.21+
- Hello API running (e.g. `cd ../../api && mvn spring-boot:run`)

## Run tests

```bash
go test -v .
```

With custom base URL:

```bash
BASE_URL=http://localhost:8080 go test -v .
```
