package main

import (
	"os"
	"testing"
)

// Base URL for the API (e.g. http://localhost:8080). Override with BASE_URL env.
func baseURL() string {
	if u := os.Getenv("BASE_URL"); u != "" {
		return u
	}
	return "http://localhost:8080"
}

// Template: test GET /hello. API requires Authorization Bearer and header "header-test".

func TestHello_Success(t *testing.T) {
	// TODO: GET /hello with Authorization and header-test, assert 200 and message
}

func TestHello_Unauthorized(t *testing.T) {
	// TODO: GET /hello without valid Authorization, assert 401
}

func TestHello_BadRequest(t *testing.T) {
	// TODO: GET /hello without header-test, assert 400
}
