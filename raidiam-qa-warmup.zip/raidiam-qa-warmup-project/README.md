# raidiam-qa-warmup-project

Hello API and test automation templates in Java, Golang, and JavaScript.

## Layout

- **api/** – Spring Boot Hello API (Bearer token + `header-test` header).
- **stack/java/** – Test automation template: JUnit 5 + RestAssured.
- **stack/javascript/** – Test automation template: Node.js + axios + supertest.

## Quick start

1. Start the API:
   ```bash
   cd api && mvn spring-boot:run
   ```
2. Run tests from any stack (in another terminal):
   - Java: `cd stack/java && mvn test`
   - Golang: `cd stack/golang && go test -v .`
   - JavaScript: `cd stack/javascript && npm install && npm test`

See each folder’s README for details.
