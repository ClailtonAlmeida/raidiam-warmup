package com.raidiam.hello;

import io.restassured.RestAssured;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;

/**
 * Template: test GET /hello (api must be running on baseUrl).
 * Requires: Authorization Bearer token, header "header-test".
 */
class HelloApiTest {

    private static final String DEFAULT_BASE_URL = "http://localhost:8080";

    @BeforeAll
    static void setup() {
        String baseUrl = System.getProperty("baseUrl", DEFAULT_BASE_URL);
        RestAssured.baseURI = baseUrl;
    }

    @Test
    void success_withValidHeaders() {
        // TODO: call GET /hello with Authorization and header-test, assert 200 and body
    }

    @Test
    void unauthorized_whenAuthorizationMissing() {
        // TODO: call GET /hello without Authorization, assert 401
    }

    @Test
    void badRequest_whenHeaderTestMissing() {
        // TODO: call GET /hello without header-test, assert 400
    }
}
