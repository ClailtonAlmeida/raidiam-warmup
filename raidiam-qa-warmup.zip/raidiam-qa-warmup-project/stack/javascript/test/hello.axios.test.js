'use strict';

const { describe, it, before } = require('node:test');
const axios = require('axios');

const BASE_URL = process.env.BASE_URL || 'http://localhost:8080';

let client;

describe('Hello API (axios)', () => {
  before(() => {
    client = axios.create({
      baseURL: BASE_URL,
      validateStatus: () => true,
    });
  });

  it('success with valid headers', async () => {
    // TODO: GET /hello with Authorization Bearer and header-test, assert 200 and body
  });

  it('unauthorized when Authorization missing', async () => {
    // TODO: GET /hello without Authorization, assert 401
  });

  it('bad request when header-test missing', async () => {
    // TODO: GET /hello without header-test, assert 400
  });
});
