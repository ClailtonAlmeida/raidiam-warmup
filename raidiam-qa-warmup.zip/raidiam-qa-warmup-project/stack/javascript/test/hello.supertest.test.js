'use strict';

const { describe, it } = require('node:test');
const supertest = require('supertest');

const BASE_URL = process.env.BASE_URL || 'http://localhost:8080';
const request = supertest(BASE_URL);

describe('Hello API (supertest)', () => {
  it('success with valid headers', async () => {
    // TODO: GET /hello with Authorization Bearer and header-test, assert 200 and body
  });

  it('unauthorized when Authorization missing', async () => {
    // TODO: GET /hello without Authorization, assert 401
  });

  it('bad request when header-test missing', async () => {
    // TODO: GET /hello without header-test, assert 400
  });
});
