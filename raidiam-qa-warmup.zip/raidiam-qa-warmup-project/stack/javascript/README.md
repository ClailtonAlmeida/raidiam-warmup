# Hello API – Test automation (JavaScript)

Template: **Node.js** test runner with **axios** and **supertest**.

## Prerequisites

- Node.js 18+ (for `node --test`)
- Hello API running (e.g. `cd ../../api && mvn spring-boot:run`)

## Install

```bash
npm install
```

## Run tests

All tests (axios + supertest):

```bash
npm test
```

Only axios-based tests:

```bash
npm run test:axios
```

Only supertest-based tests:

```bash
npm run test:supertest
```

With custom base URL:

```bash
BASE_URL=http://localhost:8080 npm test
```
